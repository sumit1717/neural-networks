class BaseLayer:
    def __int__(self):
        self.trainable = False
        self.weights = []
